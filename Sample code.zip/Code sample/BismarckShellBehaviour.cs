﻿using UnityEngine;
using System.Collections;

public class BismarckShellBehaviour : MonoBehaviour {
	public GameObject explosion;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		RaycastHit hitInfo;
		transform.Translate (transform.forward * Time.deltaTime * 200f, Space.World);
		float tf = Time.deltaTime;
		if (tf == 0) {
			tf = 0.001f;
		}
		if(Physics.Raycast(transform.position,transform.forward,out hitInfo,tf * 400f)){
			if(hitInfo.collider.gameObject.CompareTag("Player")){
				hitInfo.collider.gameObject.SendMessage("OnHealthCalc",SendMessageOptions.DontRequireReceiver);
				GameObject gb = (GameObject)Instantiate(explosion,transform.position,Quaternion.identity);
				Destroy (this.gameObject);
			}
		}
	}
}
