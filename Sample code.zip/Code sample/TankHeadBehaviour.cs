﻿using UnityEngine;
using System.Collections;

public class TankHeadBehaviour : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

	}

	void Damage(float val){
		transform.parent.SendMessage ("Damage", val, SendMessageOptions.DontRequireReceiver);
	}

}
