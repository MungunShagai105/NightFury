﻿using UnityEngine;
using System.Collections;
using GlobalInfo;

public class TankBehaviour : MonoBehaviour {
	private bool shootFlag = false;

	public Transform playerPos;
	public Transform turret;
	public Transform cannon;
	public Transform cannonSp;
	public GameObject explode;
	public GameObject shoot_Flame;
	public WheelCollider[] colliders;
	public Transform centerOfMass;
	public GameObject tankShell;
	public Transform[] wayPoints;

	private Vector3 currentWaypoint;
	private int currentIndex = 0;
	// Use this for initialization
	void Start () {

		foreach (WheelCollider col in colliders) {
			col.brakeTorque = Mathf.Infinity;
		}
		GetComponent<Rigidbody>().centerOfMass = centerOfMass.localPosition;
		currentWaypoint = wayPoints [currentIndex].position;
	}
	
	// Update is called once per frame
	void Update () {

		if (shootFlag) {
			Vector3 lookAtPos = new Vector3(playerPos.position.x,turret.position.y,playerPos.position.z);
			float turret_Angle = Vector3.Angle(turret.forward,(lookAtPos - turret.position).normalized);
			if(turret_Angle > 3f){
				if(Vector3.Angle(turret.right,(lookAtPos - turret.position).normalized) < 90f){
					turret.RotateAround(turret.position,turret.up,Time.deltaTime * 40f);
				}else{
					turret.RotateAround(turret.position,turret.up,-Time.deltaTime * 40f);
				}
			}
			return;
		}

		Vector3 lookPos = new Vector3(playerPos.position.x,turret.position.y,playerPos.position.z);
		float turret_Ang = Vector3.Angle(turret.forward,(lookPos - turret.position).normalized);
		if(turret_Ang > 3f){
			if(Vector3.Angle(turret.right,(lookPos - turret.position).normalized) < 90f){
				turret.RotateAround(turret.position,turret.up,Time.deltaTime * 40f);
			}else{
				turret.RotateAround(turret.position,turret.up,-Time.deltaTime * 40f);
			}
		}

		transform.Translate (transform.forward * Time.deltaTime * 2f,Space.World);
//		turret.localRotation = Quaternion.Slerp (turret.localRotation, Quaternion.identity, Time.deltaTime);
		Vector3 lookAtVector = new Vector3 (currentWaypoint.x, transform.position.y, currentWaypoint.z);
		float angle = Vector3.Angle (transform.forward, (lookAtVector - transform.position).normalized);
		if (angle > 10f) {
			if(Vector3.Angle(transform.right,(lookAtVector - transform.position).normalized) < 90f){
				transform.RotateAround(transform.position,transform.up,Time.deltaTime * 15f);
			}else{
				transform.RotateAround(transform.position,transform.up,-Time.deltaTime * 15f);
			}
		}

		//Within Next Waypoint Range
		if (Vector3.Distance (transform.position, currentWaypoint) < 10f){
			shootFlag = true;
			currentIndex ++;
			if(currentIndex >= wayPoints.Length){
				currentIndex = 0;
    		}
			currentWaypoint = wayPoints[currentIndex].position;
			StartCoroutine(ShootingBehaviour());
		}

	}

	IEnumerator ShootingBehaviour(){
		yield return new WaitForSeconds (5f);
		GameObject flame = (GameObject)Instantiate (shoot_Flame, transform.position, Quaternion.identity);
		flame.transform.parent = turret.transform;
		flame.transform.localRotation = Quaternion.identity;
		flame.transform.localPosition = Vector3.zero;

		GameObject gb = (GameObject)Instantiate (tankShell, cannonSp.position, turret.rotation);
		gb.transform.LookAt (CalcRandomPos ());
		yield return new WaitForSeconds (2f);
		GameObject flame1 = (GameObject)Instantiate (shoot_Flame, transform.position, Quaternion.identity);
		flame1.transform.parent = turret.transform;
		flame1.transform.localRotation = Quaternion.identity;
		flame1.transform.localPosition = Vector3.zero;
		GameObject gb1 = (GameObject)Instantiate (tankShell, cannonSp.position, turret.rotation);
		gb1.transform.LookAt (CalcRandomPos ());
		yield return new WaitForSeconds (3f);
		shootFlag = false;
	}

	Vector3 CalcRandomPos(){
		float xRand = Random.Range (-5f, 5f);
		float zRand = Random.Range (-5f, 5f);
		Vector3 retVal = new Vector3(playerPos.position.x + xRand,0,playerPos.position.z + zRand);
		return retVal;
	}
	void Damage(float val){
		GameObject gb = (GameObject)Instantiate (explode, transform.position, Quaternion.identity);
		GlobalInfo.MainGameInfo.score += 1;
		Destroy (this.gameObject);
	}

	void OnCollisionEnter(Collision col){

		if(col.gameObject.CompareTag("Target")){
			print ("aaa");
			Physics.IgnoreCollision(this.GetComponent<Collider>(),col.collider,true);
		}
	}
}
