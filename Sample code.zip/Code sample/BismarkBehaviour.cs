﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BismarkBehaviour : MonoBehaviour {
	public int bismarck_Number = -1;
	public float timeShootRange = 3f;
	public Transform shootPos;
	public Transform playerPos;
	public GameObject bismarckShell;
	public List<Transform> wayPoint = new List<Transform>();
	public GameObject bismarckShootFlame;
	public float speed = 3f;
	public Transform flamePos_1;
	public Transform flamePos_2;
	public GameObject explosion;
	public GameObject finalSmoke;
	public GameObject smoke;

	private int nextIndexNumber = 0;
	private float timeCounter = 0;
	private bool isReachFlag = false;
	private bool deathFlag = false;
	private bool shootFlag = false;
	private int health = 30;
	private Vector3 nextWaypoint = Vector3.zero;
	// Use this for initialization
	void Start () {
		GameObject gb = GameObject.Find ("BismarckWaypoint_" + bismarck_Number.ToString());
		foreach (Transform tf in gb.transform) {
			wayPoint.Add (tf);
		}
		nextWaypoint = wayPoint [nextIndexNumber].position;
		playerPos = GameObject.Find ("MainBase").transform;
	}
	
	// Update is called once per frame
	void Update () {

		if (deathFlag) {
			transform.Translate(-Vector3.up * Time.deltaTime * 1.1f,Space.Self);
			transform.RotateAroundLocal(Vector3.right,Time.deltaTime * 0.03f);
			return;
		}
		timeCounter += Time.deltaTime;

		Vector3 lookVector = new Vector3 (nextWaypoint.x, transform.position.y, nextWaypoint.z);
		float angle = Vector3.Angle (transform.forward, (lookVector - transform.position).normalized);

		if(angle > 5f){
			if(Vector3.Angle(transform.right,(lookVector - transform.position).normalized) < 90f){
				transform.RotateAroundLocal(Vector3.up,Time.deltaTime * 0.1f);
			}else{
				transform.RotateAroundLocal(Vector3.up,-Time.deltaTime * 0.1f);
			}
		}

		if(!isReachFlag){
			if(!shootFlag){
				transform.Translate (transform.forward * Time.deltaTime * speed, Space.World);
			}

			if(Vector3.Distance(transform.position,nextWaypoint) < 10f){
				nextIndexNumber ++;
				if(nextIndexNumber >= wayPoint.Count){
					nextIndexNumber = 0;
				}
				nextWaypoint = wayPoint[nextIndexNumber].position;
				isReachFlag = true;	
				StartCoroutine(ReachAction());
			}
		}

		if (timeCounter > 10f) {
			timeCounter = 0;
			StartCoroutine(ShootAction());
		}

	}

	IEnumerator ShootAction(){
		shootFlag = true;
		yield return  new WaitForSeconds (0.5f);
		foreach (Transform tf in shootPos) {
			GameObject gb = (GameObject)Instantiate(bismarckShootFlame,tf.position,Quaternion.identity);
			GameObject shell = (GameObject) Instantiate(bismarckShell,tf.position,Quaternion.identity);
			gb.transform.LookAt(playerPos);
			Vector3 target = new Vector3(playerPos.position.x + Random.Range(-10f,10f),0,playerPos.position.z + Random.Range(-10f,10f));
			shell.transform.LookAt(target);
			yield return new WaitForSeconds(0.2f);
			
		}
		yield return new WaitForSeconds (0.5f);
		timeCounter = 0;
		shootFlag = false;

	}

	IEnumerator ReachAction(){

		yield return new WaitForSeconds(7f);
		isReachFlag = false;
	}

	void Damage(float val){
		if (health < 0) {
			return;
		}
		health -= 1;
		if(health == 50){
			GameObject gb = (GameObject)Instantiate(smoke,flamePos_1.position,Quaternion.identity);
			gb.transform.parent = transform;
		}
		if (health == 20) {
			GameObject gb = (GameObject)Instantiate(smoke,flamePos_2.position,Quaternion.identity);
			gb.transform.parent = transform;
		}
		if(health < 0){
			deathFlag = true;
			StartCoroutine(DeathAction());
			GameObject gb = (GameObject)Instantiate(explosion,transform.position,Quaternion.identity);
			GameObject gb1 = (GameObject)Instantiate(finalSmoke,transform.position,Quaternion.identity);

		}
	}

	IEnumerator DeathAction(){
		yield return new WaitForSeconds (3f);
		Destroy (this.gameObject);
	}
}
