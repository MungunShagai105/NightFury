﻿using UnityEngine;
using System.Collections;

public class TransportShipBehaviour : MonoBehaviour {
	private bool landingFlag = false;
	private bool tankMovingFlag = false;
	private bool tankThreadStarted = false;

	public GameObject explosion;
	public Transform[] tanks;
	public Transform landingPos;
	public float speed;

	// Use this for initialization
	void Start () {
		Vector3 lookAtPos = new Vector3 (landingPos.position.x, transform.position.y, landingPos.position.z);
		transform.LookAt (lookAtPos);
	}
	
	// Update is called once per frame
	void Update () {
		if(!landingFlag){
			transform.Translate (transform.forward * Time.deltaTime * speed, Space.World);
		}else{
			transform.GetComponent<Animator>().enabled = true;
			if(!tankThreadStarted){
				StartCoroutine(TankBehaviour());
				tankThreadStarted = true;
			}
		}
		if (Vector3.Distance (transform.position, landingPos.position) < 7f) {
			landingFlag = true;
		}

		if (tankMovingFlag) {
			foreach (Transform tf in tanks) {
				tf.Translate(tf.forward * Time.deltaTime * 5f,Space.World);
			}
		}
	}

	IEnumerator TankBehaviour(){
		yield return new WaitForSeconds (2f);
		tankMovingFlag = true;
		yield return new WaitForSeconds (7f);
		tankMovingFlag = false;
		foreach (Transform tf in tanks) {
			tf.parent = null;
			tf.GetComponent<Rigidbody>().isKinematic = false;
			tf.GetComponent<TankBehaviour>().enabled = true;
		}
	}

	public void Damage(float val){
		GameObject gb = (GameObject)Instantiate (explosion, transform.position, Quaternion.identity);
		Destroy (this.gameObject);
	}
}
