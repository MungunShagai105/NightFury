﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RoyalFrigateBehaviour : MonoBehaviour {
	public int royal_Number;
	public List<Transform> wayPoint = new List<Transform>();
	public Transform playerPos;
	public GameObject bismarckShootFlame;
	public GameObject bismarckShell;
	public Transform shootPos;
	public GameObject smoke;
	public Transform flamePos_1;
	public Transform flamePos_2;
	public GameObject explosion;
	public GameObject afterExplodeEffect;
	public float shootPeriod = 5f;
	public float speed;

	private Vector3 nextWaypoint;
	private int nextIndexNumber;
	private bool deathFlag = false;
	private bool shootFlag = false;
	private bool isReachFlag = false;
	private float timeCounter = 0;
	private int health;
	// Use this for initialization
	void Start () {
		GameObject gb = GameObject.Find ("RoyalFrigateWaypoint_" + royal_Number.ToString());
		foreach (Transform tf in gb.transform) {
			wayPoint.Add (tf);
		}
		nextWaypoint = wayPoint [nextIndexNumber].position;
		playerPos = GameObject.Find ("MainBase").transform;
	}
	
	// Update is called once per frame
	void Update () {
		
		if (deathFlag) {
			transform.Translate(-Vector3.up * Time.deltaTime * 0.3f,Space.Self);
			transform.RotateAroundLocal(Vector3.right,Time.deltaTime * 0.1f);
			return;
		}
		timeCounter += Time.deltaTime;
		
		Vector3 lookVector = new Vector3 (nextWaypoint.x, transform.position.y, nextWaypoint.z);
		float angle = Vector3.Angle (transform.forward, (lookVector - transform.position).normalized);
		
		if(angle > 5f){
			if(Vector3.Angle(transform.right,(lookVector - transform.position).normalized) < 90f){
				transform.RotateAroundLocal(Vector3.up,Time.deltaTime);
			}else{
				transform.RotateAroundLocal(Vector3.up,-Time.deltaTime );
			}
		}
		
		if(!isReachFlag){

				transform.Translate (transform.forward * Time.deltaTime * speed, Space.World);

			
			if(Vector3.Distance(transform.position,nextWaypoint) < 10f){
				nextIndexNumber ++;
				if(nextIndexNumber >= wayPoint.Count){
					nextIndexNumber = 0;
				}
				nextWaypoint = wayPoint[nextIndexNumber].position;
				isReachFlag = true;	
				StartCoroutine(ReachAction());
			}
		}
		
		if (timeCounter > shootPeriod) {
			timeCounter = 0;
			StartCoroutine(ShootAction());
		}
		
	}
	
	IEnumerator ShootAction(){
		shootFlag = true;
		foreach (Transform tf in shootPos) {
			GameObject gb = (GameObject)Instantiate(bismarckShootFlame,tf.position,Quaternion.identity);
			GameObject shell = (GameObject) Instantiate(bismarckShell,tf.position,Quaternion.identity);
			gb.transform.LookAt(playerPos);
			Vector3 target = new Vector3(playerPos.position.x + Random.Range(-20f,20f),0,playerPos.position.z + Random.Range(-20f,20f));
			shell.transform.LookAt(target);
			yield return new WaitForSeconds(0.1f);
			
		}
		timeCounter = 0;
		shootFlag = false;
		
	}
	
	IEnumerator ReachAction(){
		
		yield return new WaitForSeconds(8f);
		isReachFlag = false;
	}
	
	void Damage(float val){
		if (health < 0) {
			return;
		}

		deathFlag = true;
		StartCoroutine(DeathAction());
		GameObject gb = (GameObject)Instantiate(explosion,transform.position,Quaternion.identity);
		GameObject afterExplode = (GameObject)Instantiate (afterExplodeEffect, transform.position, Quaternion.identity);
		health = -1;
	}
	
	IEnumerator DeathAction(){
		yield return new WaitForSeconds (20f);
		Destroy (this.gameObject);
	}
}
